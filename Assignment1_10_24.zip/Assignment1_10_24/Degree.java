package Assignment1_10_24;

public class Degree {
	
	public void getDegree() {
        System.out.println("I got a degree");
    }
}
