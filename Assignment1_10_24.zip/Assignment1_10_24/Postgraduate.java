package Assignment1_10_24;

public class Postgraduate extends Degree{

	public void getDegree() {
        System.out.println("I am a Postgraduate");
    }
}
